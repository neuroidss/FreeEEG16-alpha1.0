socat  pty,link=/tmp/ttyBLE1,raw  tcp:192.168.1.101:23
