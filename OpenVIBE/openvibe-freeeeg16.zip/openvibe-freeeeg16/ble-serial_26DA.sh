ble-serial -d 34:B4:72:4E:26:DA -w 6e400002-b5a3-f393-e0a9-e50e24dcca9e -p /tmp/ttyBLE1
