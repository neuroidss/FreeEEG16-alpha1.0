socat  pty,link=/tmp/ttyBLE0,raw  tcp:192.168.1.100:23

